module InicioFX {

    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;

    opens sample;
}