module T02.Pestaniass {
    requires javafx.fxml;
    requires javafx.graphics;
    requires javafx.controls;
    opens sample;
}